import { LightningElement,api } from 'lwc';

export default class CertificationRequestRecordForm extends LightningElement {
    @api recordId;
    @api objectApiName;
}