import { LightningElement,api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
export default class CreateOverride extends NavigationMixin(LightningElement) {
    @api recordId;
    
    handleSubmit(event) {
        console.log('onsubmit: '+ event.detail.fields);
        
        
    }

    handleSuccess(event) {
        const updatedRecord = event.detail.id;
        console.log('onsuccess: ', updatedRecord);

        const evt = new ShowToastEvent({
            title: 'Success',
            message: 'Employee record is created',
            variant: 'success',
        });
        
        this.dispatchEvent(evt);
        
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: updatedRecord,
                actionName: 'view'
            }
            
        });
        
    }

    navigateToListView() {
        // Navigate to the Employee object's Recent list view.
       this[NavigationMixin.Navigate]({
            type: 'standard__navItemPage',
            attributes: {
                apiName:'Employee',
            }   
        });
        
        eval("$A.get('e.force:refreshView').fire();");
    }

    

}