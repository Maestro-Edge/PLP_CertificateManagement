import { LightningElement,track, wire } from 'lwc';
import { getListUi } from 'lightning/uiListApi';

import CERTIFICATION_OBJECT from '@salesforce/schema/Certification__c';
import { NavigationMixin } from 'lightning/navigation';

export default class EmpertificationList extends NavigationMixin(LightningElement) 
{
    @track listViewResult;
    @track error;
    @wire(getListUi, {
        objectApiName: CERTIFICATION_OBJECT,
        listViewApiName: 'All'
    })
    listView({error,data}) {
        if (data) {
            this.listViewResult = data.records.records;
        } else if (error) {
            this.error = error;
        }
    }

    handleCerView(event)
    {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: event.target.value,
                objectApiName: 'Certification__c',
                actionName: 'view',
            },
        });
        eval("$A.get('e.force:refreshView').fire();");
    }

    createNewCertification()
    {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Certification__c',
                actionName: 'new'
            }
        });
        eval("$A.get('e.force:refreshView').fire();");
    }
}