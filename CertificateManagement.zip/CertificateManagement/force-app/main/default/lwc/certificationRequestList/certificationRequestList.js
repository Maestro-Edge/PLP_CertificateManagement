import { LightningElement,track, wire } from 'lwc';
import { getListUi } from 'lightning/uiListApi';

import CERTIFICATION_REQUEST_OBJECT from '@salesforce/schema/Certification_Request__c';
import { NavigationMixin } from 'lightning/navigation';

export default class CertificationRequestList extends NavigationMixin(LightningElement) 
{
    @track listViewResult;
    @track error;
    @wire(getListUi, {
        objectApiName: CERTIFICATION_REQUEST_OBJECT,
        listViewApiName: 'All'
    })
    listView({error,data}) {
        if (data) {
            this.listViewResult = data.records.records;
        } else if (error) {
            this.error = error;
        }
    }

    handleCRView(event)
    {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: event.target.value,
                objectApiName: 'Certification_Request__c',
                actionName: 'view',
            },
        });
        eval("$A.get('e.force:refreshView').fire();");
    }

    createcreateNewCerticationRequest()
    {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Certification_Request__c',
                actionName: 'new'
            }
        });
        eval("$A.get('e.force:refreshView').fire();");
    }
}