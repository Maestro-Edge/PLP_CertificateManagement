import { LightningElement,track, wire, api } from 'lwc';
import { getListUi } from 'lightning/uiListApi';

import EMPLOYEE_OBJECT from '@salesforce/schema/Employee__c';
import { NavigationMixin } from 'lightning/navigation';


export default class EmployeeList extends NavigationMixin(LightningElement) 
{
    @api recordId;
    @api objectApiName;
    @track listViewResult;
    @track error;
    @track recordId;

    

    @wire(getListUi, {
        objectApiName: EMPLOYEE_OBJECT,
        listViewApiName: 'All'
    })
    listView({error,data}) {
        if (data) {
            this.listViewResult = data.records.records;
        } else if (error) {
            this.error = error;
        }
    }

    handleEmpView(event)
    {

        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: event.target.value,
                objectApiName: 'Employee__c',
                actionName: 'view',
            },
        });
        eval("$A.get('e.force:refreshView').fire();");
    }

    createNewEmployee()
    {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Employee__c',
                actionName: 'new'
            }
        });
        eval("$A.get('e.force:refreshView').fire();");
    }

}