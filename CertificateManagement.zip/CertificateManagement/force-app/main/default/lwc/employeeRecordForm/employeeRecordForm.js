import { LightningElement, api } from 'lwc';


export default class EmployeeRecordForm extends LightningElement {
    @api recordId;
    @api objectApiName;

}