import { LightningElement, track, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import searchCertifications from "@salesforce/apex/Certification.searchCertifications";
export default class CertificationSearch extends NavigationMixin(LightningElement) {
    
    @track searchTerm = '';

    @wire(searchCertifications, { searchTerm: '$searchTerm' })
    certifications;

    handleSearchTermChange(event) {
        // long as this function is being called within a delay of 300 ms.
        // This is to avoid a very large number of Apex method calls.

        window.clearTimeout(this.delayTimeout);
        const searchTerm = event.target.value;

            
        this.delayTimeout = setTimeout(() => {
            this.searchTerm = searchTerm;
        }, 300);
    }

    get hasResults() {
        return (this.certifications.data.length > 0);
    }

    handleEmpView(event)
    {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: event.target.value,
                objectApiName: 'Certification__c',
                actionName: 'view',
            },
        });
        eval("$A.get('e.force:refreshView').fire();");
    }
    
}