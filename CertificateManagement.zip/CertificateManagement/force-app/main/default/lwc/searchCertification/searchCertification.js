import { LightningElement, track, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';

import { deleteRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';
import searchCertifications from "@salesforce/apex/Certification.searchCertifications";
export default class SearchCertification extends NavigationMixin(LightningElement) {
   
    @track searchTerm = '';

    @wire(searchCertifications, { searchTerm: '$searchTerm' })
    certifications;
    

    handleSearchTermChange(event) {

        // long as this function is being called within a delay of 300 ms.
        // This is to avoid a very large number of Apex method calls.

        window.clearTimeout(this.delayTimeout);
        const searchTerm = event.target.value;

        // eslint-disable-next-line @lwc/lwc/no-async-operation      
        this.delayTimeout = setTimeout(() => {
            this.searchTerm = searchTerm;
        }, 300);
    }

    get hasResults() {
        return (this.certifications.data.length > 0);
    }

    handleEmpView(event)
    {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: event.target.value,
                objectApiName: 'Certification__c',
                actionName: 'view',
            },
        });
        return refreshApex(this.loadBears);
    }
    
    createNew()
    {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Certification__c',
                actionName: 'new'
            }
        });
        return refreshApex(this.loadBears);
        
    }

    deleteAccount(event) {
        const recordId = event.target.value;
        deleteRecord(recordId)
            .then(() => {
              window.location.reload();
              
            })
            .then(() => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Record Is  Deleted',
                        variant: 'success',
                    }),
                );
                
            })
            .catch(error => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error While Deleting record',
                        message: error.message,
                        variant: 'error',
                    }),
                );
            });
            
    }
}