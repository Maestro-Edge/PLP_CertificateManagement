import { LightningElement, api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
export default class CrEdit extends NavigationMixin(LightningElement) {
    
    handleAccountCreated(event){
        const updatedRecord = event.detail.id;

        const evt = new ShowToastEvent({
            title: 'Success',
            message: 'Certification Request record is created',
            variant: 'success',
        });
        this.dispatchEvent(evt);

        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: updatedRecord,
                actionName: 'view'
            }
        });
        eval("$A.get('e.force:refreshView').fire();");
    }
    
    navigateToListView() {
        // Navigate to the Certification Request object's Recent list view.
       this[NavigationMixin.Navigate]({
            type: 'standard__navItemPage',
            attributes: {
                apiName:'Certification_Request',
            }   
        });
        
        eval("$A.get('e.force:refreshView').fire();");
    }
}