import { LightningElement,api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class CertificationRequestNew extends NavigationMixin(LightningElement) {
    @api recordId;
    handleSubmit(event) {
        console.log('onsubmit: '+ event.detail.fields);
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: this.recordId,
                actionName: 'view'
            }
            
        });
        //eval("$A.get('e.force:refreshView').fire();");
        
    }
    handleSuccess(event) {
        const updatedRecord = event.detail.id;
        console.log('onsuccess: ', updatedRecord);
        const evt = new ShowToastEvent({
            title: 'Success',
            message: 'Certification Request record is updated',
            variant: 'success',
        });
        this.dispatchEvent(evt);
    }

    navigateToListView() {
        // Navigate to the Contact object's Recent list view.
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: this.recordId,
                actionName: 'view'
            }
            
        });
        eval("$A.get('e.force:refreshView').fire();");
    }

    

}