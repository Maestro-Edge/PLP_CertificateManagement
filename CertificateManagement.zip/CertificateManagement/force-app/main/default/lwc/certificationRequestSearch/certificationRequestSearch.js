import { LightningElement, track, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import searchCertificationRequest from "@salesforce/apex/CertificationRequest.searchCertificationRequest";
export default class CertificationRequestSearch extends NavigationMixin(LightningElement) {
    
    @track searchTerm = '';

    @wire(searchCertificationRequest, { searchTerm: '$searchTerm' })
    certificationRequests;

    handleSearchTermChange(event) {

        // long as this function is being called within a delay of 300 ms.
        // This is to avoid a very large number of Apex method calls.

        window.clearTimeout(this.delayTimeout);
        const searchTerm = event.target.value;

            
        this.delayTimeout = setTimeout(() => {
            this.searchTerm = searchTerm;
        }, 300);
    }

    get hasResults() {
        return (this.certificationRequests.data.length > 0);
    }

    handleEmpView(event)
    {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: event.target.value,
                objectApiName: 'Certification_Request__c',
                actionName: 'view',
            },
        });
        eval("$A.get('e.force:refreshView').fire();");
    }
    
}