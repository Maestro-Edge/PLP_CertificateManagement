import { LightningElement,api } from 'lwc';

export default class CertificationRecordForm extends LightningElement {
    @api recordId;
    @api objectApiName;
}